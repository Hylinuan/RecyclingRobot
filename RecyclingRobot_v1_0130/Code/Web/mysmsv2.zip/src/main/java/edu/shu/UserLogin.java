package edu.shu;
import org.springframework.ui.Model;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.TreeSet;
import org.springframework.web.bind.annotation.*;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.beans.factory.annotation.Autowired;

@Controller
public class UserLogin{
  private HttpServletRequest request;

    @Autowired
    Environment env;

	@Autowired
	public void setRequest(HttpServletRequest request){
	   this.request = request;
	}

	@GetMapping("/")
	public String login(Model model) {
	  return "index"; // return "login"
	}

    @GetMapping("/index")
    public String getindex(Model model) {
      
     model.addAttribute("message","This is your message");
     return "index";
    }


    @PostMapping("/index")
    public String verification(Model model,
				   @RequestParam("account") String ad,
				   @RequestParam("passwd") String pw) throws Exception {
	   String us="http://"+env.getProperty("ams.ip")+":"+env.getProperty("ams.port")+"/login?account=";
	   URL url = new URL(us+ad+"&passwd="+pw+"&ip="+request.getRemoteAddr());
	   BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
	   String str = new String(in.readLine());
	   String[] ss = str.split(",");
	   switch(ss[0]){
	   case "0":
		 model.addAttribute("account", ad);
                 model.addAttribute("level", ss[2]);
	     return "admin";
	   case "1":
		 model.addAttribute("err", "帳號不存在!");
             return "index";
          case "2":
		 model.addAttribute("err", "密碼錯誤!");
             return "index";
          default :
	     return "login";
	   }
    }


}
