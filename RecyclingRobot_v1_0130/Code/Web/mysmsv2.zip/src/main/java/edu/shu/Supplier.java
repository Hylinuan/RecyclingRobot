package edu.shu;
import org.springframework.web.bind.annotation.*;
import java.sql.*;

@RestController
public class Supplier {
   private static final String driver = "org.apache.derby.jdbc.EmbeddedDriver";
   private static final String url = "jdbc:derby:e50;create=true";

   @GetMapping(value={"/derby/{table}"})
   public String get(@PathVariable("table") String tb,
                     @RequestParam("ask") String ask,
                     @RequestParam("sql") String sql) {

      Connection con = null ;
      Statement st = null;

      try{
         Class.forName(driver) ;
         con = DriverManager.getConnection(url);
         st = con.createStatement();

         if(ask.equals("query")){
            ResultSet result = st.executeQuery(sql);
            StringBuffer r = new StringBuffer();
            while (result.next()) {
               int i;
               for(i=1; i<13; i++) r.append(result.getString(i)+",");
               r.append(result.getString(i)+"<br>");
            }
            return r.toString();
         }else if(ask.equals("create")){
            st.executeUpdate("CREATE TABLE "+tb.toUpperCase()+" (ID VARCHAR(6) PRIMARY KEY," + //廠商$
                       "NAME VARCHAR(30), ADDR1 VARCHAR(30)," + //名稱、地址1
                       "ADDR2 VARCHAR(30), PHONE1 VARCHAR(16)," + //地址2、電話1
                       "PHONE2 VARCHAR(16), FAX VARCHAR(15)," + //電話2、傳真機
                       "MANAGER VARCHAR(16), TAXID VARCHAR(8)," + //負責人、統一編號
                       "NATURE1 VARCHAR(20), NATURE2 VARCHAR(20)," + //營業性質1、營業性質2
                       "PIC VARCHAR(16), DATE VARCHAR(10))"); //經辦人、建檔日
            return tb.toUpperCase()+" table created";
         }else if(ask.equals("drop")){
            st.executeUpdate("DROP TABLE "+tb.toUpperCase());
            return tb.toUpperCase()+" table deleted";
         }else{
            st.executeUpdate(sql);
            return "ok";
         }
      } catch (Exception ex) {
         return ex.getMessage();
      } finally {
         try {
            if (st != null) { st.close(); }
            if (con != null) { con.close(); }
         } catch (SQLException ex) { return ex.getMessage();}
      } //End of finally
   } //End of get

/*   @GetMapping(value={"/derby/{table}/{function}"})
   public String Sup(@PathVariable("table") String tb,
                     @PathVariable("function") String fun) {
      Connection con = null ;
      Statement st = null;
      try {
         Class.forName(driver) ;
         con = DriverManager.getConnection(url);
         st = con.createStatement();
         st.executeUpdate("CREATE TABLE SUPPLIER (ID VARCHAR(6) PRIMARY KEY," + //廠商編號
                          "NAME VARCHAR(30), ADDR1 VARCHAR(30)," + //名稱、地址1
                          "ADDR2 VARCHAR(30), PHONE1 VARCHAR(16)," + //地址2、電話1
                          "PHONE2 VARCHAR(16), FAX VARCHAR(15)," + //電話2、傳真機
                          "MANAGER VARCHAR(16), TAXID VARCHAR(8)," + //負責人、統一編號
                          "NATURE1 VARCHAR(20), NATURE2 VARCHAR(20)," + //營業性質1、營業性質2
                          "PIC VARCHAR(16), DATE VARCHAR(10))"); //經辦人、建檔日
         return "supplier table created";
      } catch (Exception ex) {
         return ex.getMessage();
      } finally {
         try {
            if (st != null) { st.close(); }
            if (con != null) { con.close(); }
         } catch (SQLException ex) { return ex.getMessage();}
      }
   } //End of supplier create

   @GetMapping(value={"/derby/supplier/drop"})
   public String dropSup() {
      Connection con = null ;
      Statement st = null;
      try {
         Class.forName(driver) ;
         con = DriverManager.getConnection(url);
         st = con.createStatement();
         st.executeUpdate("DROP TABLE SUPPLIER");
         return "supplier table deleted";
      } catch (Exception ex) {
         return ex.getMessage();
      } finally {
         try {
            if (st != null) { st.close(); }
            if (con != null) { con.close(); }
         } catch (SQLException ex) { return ex.getMessage();}
      }
   }*/ //End of supplier drop

} //End of class

