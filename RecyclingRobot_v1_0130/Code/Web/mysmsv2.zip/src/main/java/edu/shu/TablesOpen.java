package edu.shu;
import java.net.*;
import javax.servlet.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.beans.factory.annotation.Autowired;

@Controller
public class TablesOpen {

  @Autowired
  Environment env;

  @GetMapping("/table/{id}")
  public String post(HttpServletResponse httpResponse) throws Exception {
      httpResponse.sendRedirect("http://"+env.getProperty("server.ip")+":"+env.getProperty("server.port"));
      return "index";
    }

  @PostMapping("/table/{id}")
  public String get(@PathVariable int id) {
    String html;
      switch(id){
      case 0:  html="/index";    break;
      case 1:  html="/login";    break;
      case 2:  html="/product";  break;
      case 3:  html="/employee"; break;
      case 4:  html="/enter";    break;
      case 5:  html="/picking";  break;
      case 6:  html="/receipt";  break;
      case 7:  html="/payment";  break;
      case 8:  html="/deal";     break;
      case 9:  html="/requisitions"; break;
      case 10: html="/supplier"; break;
      case 11: html="/scrapped"; break;
      case 12: html="/inventory"; break;
      default :html="/error";
       }
    return html;
    }
}

