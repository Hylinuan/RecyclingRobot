package edu.shu;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class MyFunction {
/*  @GetMapping("/")
  public ModelAndView get() {
     ModelAndView modelAndView = new ModelAndView();
     modelAndView.setViewName("/index.html");
     return modelAndView;
  }*/

  @GetMapping("/page/{id}")
  public ModelAndView get(@PathVariable String id) {
       ModelAndView modelAndView = new ModelAndView();
       switch(Integer.parseInt(id)){
         case 1:
            modelAndView.setViewName("/recyclelist.html");
            break;
         case 2:
            modelAndView.setViewName("/login.html");
            break;
         case 3:
            modelAndView.setViewName("/camera.html");
            break;
         case 4:
            modelAndView.setViewName("/dispatching.html");
            break;
         case 5:
            modelAndView.setViewName("/management.html");
            break;
       }return modelAndView;
  } 
}
