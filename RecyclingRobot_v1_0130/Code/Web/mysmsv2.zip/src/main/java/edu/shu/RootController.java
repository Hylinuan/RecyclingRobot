package edu.shu;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
public class RootController {
    @RequestMapping("/")
    void manual(HttpServletResponse response) throws IOException {
       response.setHeader("Server : ", "BMI 25");
       response.setStatus(200);
    }
}
