package edu.shu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Derby {

	public static void main(String[] args) {
		SpringApplication.run(Derby.class, args);
	}
}
