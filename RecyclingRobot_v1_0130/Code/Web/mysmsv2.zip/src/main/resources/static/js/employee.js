function send(){
   if(checkSp()){ //判斷有無欄位應填而未填
      var x="";
      for(i = 1; i <= 43; i++){
         x = x+i+":"+document.getElementById("ey"+i).value+";";
      }
      alert (x);
   }
} //End of send()

function checkSp(){
   for(i = 1; i <= 11; i++){
      if(document.getElementById("ey"+i).value==""){
         alert("此欄位不可為空");
         document.getElementById("ey"+i).focus();
         return false;
      }
   }

   if(document.getElementById("ey12").value!=""){
      for(i = 13; i <= 16; i++){
         if(document.getElementById("ey"+i).value==""){
            alert("此欄位不可為空");
            document.getElementById("ey"+i).focus();
            return false;
         }
      }
   }

   if(document.getElementById("ey17").value!=""){
      for(i = 18; i <= 21; i++){
         if(document.getElementById("ey"+i).value==""){
            alert("此欄位不可為空");
            document.getElementById("ey"+i).focus();
            return false;
         }
      }
   }

   if(document.getElementById("ey22").value!=""){
      for(i = 23; i <= 26; i++){
         if(document.getElementById("ey"+i).value==""){
            alert("此欄位不可為空");
            document.getElementById("ey"+i).focus();
            return false;
         }
      }
   }

   if(document.getElementById("ey27").value!=""){
      for(i = 28; i <= 31; i++){
         if(document.getElementById("ey"+i).value==""){
            alert("此欄位不可為空");
            document.getElementById("ey"+i).focus();
            return false;
         }
      }
   }

   if(document.getElementById("ey32").value!=""){
      for(i = 33; i <= 36; i++){
         if(document.getElementById("ey"+i).value==""){
            alert("此欄位不可為空");
            document.getElementById("ey"+i).focus();
            return false;
         }
      }
   }

  for(i = 37; i <= 43; i++){
      if(document.getElementById("ey"+i).value==""){
         alert("此欄位不可為空");
         document.getElementById("ey"+i).focus();
         return false;
      }
   }
   return true;
} //End of checkForm()

function check(){
	var x;
	for(i = 1; i <= 43; i++){
	   item = document.getElementById("ey"+i);
	   if(item.value!=""){
	   switch(i){
		   case 1: case 12: case 17: case 22: case 27: case 32: case 37:
		      if(isNaN(item.value)){
			     alert("請填入數字");
			     setTimeout(function(){item.focus()}, 10);
			     return false;
		      }
		      break;
		   case 4:
		      if( item.value.toUpperCase()!="A" && item.value.toUpperCase()!="B" && item.value.toUpperCase()!="O" && item.value.toUpperCase()!="AB"){
				 alert("血型請填入A/B/O/AB");
			     setTimeout(function(){item.focus()}, 10);
				 return false;
			  }
		      break;
		   case 3:
		      if( item.value!="男" && item.value!="女" ){
				 alert("性別請填入男/女");
			     setTimeout(function(){item.focus()}, 10);
				 return false;
			  }
			  break;
		   case 8: case 9:
		      if(!fucCheckTEL(item.value)){
			     alert("請填入正確電話格式");
			     setTimeout(function(){item.focus()}, 10);
				 return false;
		      }
		      break;
		   default:
	   } //End of switch
	   } //End of if
	}
	//alert(item.id.substring(2));
} //End of check

//判斷電話
function fucCheckTEL(TEL){     
   var i,j,strTemp;     
   strTemp="0123456789-()# ";     
   for (i=0;i<TEL.length;i++){     
      j=strTemp.indexOf(TEL.charAt(i));     
      if (j==-1) return false;
   }
   return true;     
}