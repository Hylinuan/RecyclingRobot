//將選取帳號給表單的帳號欄位 
function getAccount(){
  var sAd;
  $('table .ad').each(function(i, val){
       var checkbox_cell_is_checked = $(this).prev().find('input').is(':checked');
       if(checkbox_cell_is_checked ){
          if( !sAd ){
            sAd = $(this).text()
          }else{
            sAd =sAd+","+$(this).text()
          }
        }
     document.getElementById("chlaccount").innerHTML = sAd;
     document.getElementById("chpaccount").innerHTML = sAd;
  });
}
//檢查密碼及長度 function check_passwd(){
            if(!$("#chppasswd").val().match("^[A-Za-z0-9]{6,15}$")){
                alert("請輸入由6~15字元密碼，不可為空/中文");
                return false;
            }else{
                 pass();
            }
}
//將密碼送出 function pass() {
  var sAccount = document.getElementById("chpaccount").innerHTML;
  var sPasswd = document.getElementById("chppasswd").value;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
      if (xhttp.readyState == 4 && xhttp.status == 200) {
        if(xhttp.responseText == "yes"){
			document.getElementById("yn").innerHTML ="密碼更改完成";
			loadlist();
		}else{
			document.getElementById("yn").innerHTML ="密碼更改失敗";
			loadlist();
		}
      }
    };
 xhttp.open("PUT", "/user?account=" + sAccount + "&passwd=" + sPasswd , true);
    xhttp.send();
}
