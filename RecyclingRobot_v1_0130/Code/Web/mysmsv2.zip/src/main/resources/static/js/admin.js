function zindex(i){
         switch(i){
          case 'Div3':
              document.getElementById('Div3').style.zIndex="2";
              document.getElementById('Div4').style.zIndex="0";
              document.getElementById('Div5').style.zIndex="0";
              break;
          case 'Div4':
              document.getElementById('Div3').style.zIndex="0";
              document.getElementById('Div4').style.zIndex="2";
              document.getElementById('Div5').style.zIndex="0";
              break;
          case 'Div5':
              document.getElementById('Div3').style.zIndex="0";
              document.getElementById('Div4').style.zIndex="0";
              document.getElementById('Div5').style.zIndex="2";
              break;
         }
}
function asend(){
	for( var num=3; num<=5; num++){
		ajax(num);
	}
}
function ajax(num) {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById('Div'+num).innerHTML = this.responseText;
    }
  };
  xhttp.open('GET','http://192.192.152.89:8080/page/'+num,true);
  xhttp.send();
}
