function buildform(y) {
      document.getElementById(y).style.zIndex=2;
   var x = document.getElementsByClassName("content");
   var str="";
   var i;
   for (i = 0; i < x.length; i++) {
      index=x[i].innerText.replace(/</g,"").replace(/>/g,"")
      x[i].innerHTML="<input type='text' id='sup"+i+"' tabindex='"+index+"' style='width:100%'>";
   }
   var Today=new Date();
   document.getElementById("date").innerHTML=Today.getFullYear()+"/"+(Today.getMonth()+1)+"/"+Today.getDate();
   document.getElementById("q").innerHTML="<select id='que'><option value='ID'>廠商編號</option><option value='DATE'>建檔日期</option></select>";
}

function enter(table,fnc){
//   var x = document.getElementsByClassName("content");
   var x=[];
   for (i = 0; i < 12; i++) {
      x[i]=document.getElementById("sup"+i).value;
   }
   var sql=""; //sql指令
   table = table.toUpperCase(); //table name

   if(fnc=="query"){
      if(document.getElementById("uniq").value!=""){
         sql = "SELECT * FROM "+table+" WHERE ID='"+document.getElementById("uniq").value+"'";
         setTimeout('sdata()',500);
      }else{
         switch(document.getElementById("que").value){
            case "ID":
               sql = "SELECT * FROM "+table+" ORDER BY 'id', 'date' DESC";
               break;
            case "DATE":
               sql = "SELECT * FROM "+table+" ORDER BY 'date', 'id' DESC";
               break;
         } //End of switch
      } //End of if
      ajax("GET","/derby/"+table+"?ask=query&sql="+sql,"sql");
   }else if(checkid()){
      switch(fnc){
         case "insert":
            sql+="/derby/"+table+"?ask="+fnc+"&sql="+"INSERT INTO "+table+" VALUES('";
            for(var i = 0; i < 12; i++) sql += x[i]+"','";
            sql += document.getElementById("date").innerHTML+"')";
            ajax("GET",sql,"sql");
            setTimeout('redata()',500);
            break;
         case "update":
            sql += "/derby/"+table+"?ask="+fnc+"&sql="+"UPDATE "+table+" SET ";
            if(x[1]!="") sql += "NAME='"+x[1]+"', ";
            if(x[2]!="") sql += "ADDR1='"+x[2]+"', ";
            if(x[3]!="") sql += "ADDR2='"+x[3]+"', ";
            if(x[4]!="") sql += "PHONE1='"+x[4]+"', ";
            if(x[5]!="") sql += "PHONE2='"+x[5]+"', ";
            if(x[6]!="") sql += "FAX='"+x[6]+"', ";
            if(x[7]!="") sql += "MANAGER='"+x[7]+"', ";
            if(x[8]!="") sql += "TAXID='"+x[8]+"', ";
            if(x[9]!="") sql += "NATURE1='"+x[9]+"', ";
            if(x[10]!="") sql += "NATURE2='"+x[10]+"', ";
            if(x[11]!="") sql += "PIC='"+x[11]+"', ";
            var tmp = sql.toString().lastIndexOf(',');
            var tmp2 = sql.toString().substring(0,tmp) + " WHERE ID='"+x[0]+"'";
            ajax("GET",tmp2,"sql");
            setTimeout('redata()',500);
            break;
         case "delete":
            sql += "/derby/"+table+"?ask="+fnc+"&sql="+"DELETE FROM "+table+" WHERE ID='"+x[0]+"'";
            ajax("GET",sql,"sql");
            setTimeout('redata()',500);
            break;
      } //End of switch
   } //End of if
} //End of enter

function ajax(cmd,url,target) {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById(target).innerHTML = this.responseText;
    }
  };
  xhttp.open(cmd, url, true);
  xhttp.send();
}

function checkid(){
   if(document.getElementById("sup0").value==""){
      alert("廠商編號不可為空");
      document.getElementById("sup0").focus();
      return false;
   }
   return true;
}

function redata(){
   if(document.getElementById("sql").innerHTML=="ok") document.getElementById("myForm").reset();
}

function sdata(){
      var x = document.getElementById("sql").innerHTML.split(",");
      for(i=0;i<12;i++) document.getElementById("sup"+i).value = x[i];
}
