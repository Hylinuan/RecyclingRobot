//新增帳號檢查
function check_adduser(){
            if(!$("#addaccount").val().match("^[A-Za-z0-9]{5,15}$")){
                alert("請輸入由6~15字元帳號，不可為空/中文");
                return false;
            }else if(!$("#addpasswd").val().match("^[A-Za-z0-9]{4,15}$")){
                alert("請輸入由6~15字元密碼，不可為空/中文");
                return false;
            }else{
                 adduser();
            }
}
//新增使用者
function adduser() {
	var sAccount = document.getElementById("addaccount").value;
	var sPasswd = document.getElementById("addpasswd").value;
	var sLevel = document.getElementById("addlevel").value;
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if(xhttp.readyState == 4 && xhttp.status == 200) {
			if(xhttp.responseText == "no"){
				document.getElementById("yn").innerHTML ="新增失敗";
			}else{
				document.getElementById("yn").innerHTML ="新增成功";
				loadlist();
			}
		}
	};
	xhttp.open("POST", "/user?account=" + sAccount + "&passwd=" + sPasswd + "&level=" + sLevel, true);
	xhttp.send();
}
