function zindex(i){
         switch(i){
          case 'Div0':
              document.getElementById('Div1').style.zIndex="0";
              document.getElementById('Div2').style.zIndex="0";
              break;
          case 'Div1':
              document.getElementById('Div1').style.zIndex="2";
              document.getElementById('Div2').style.zIndex="0";
              break; 
          case 'Div2':
              document.getElementById('Div1').style.zIndex="0";
              document.getElementById('Div2').style.zIndex="2";
              break;
         }

}

function asend(){
	for( var num=1; num<=2; num++){
		ajax(num);
	}
}

function ajax(num) {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById('Div'+num).innerHTML = this.responseText;
    }
  };
  xhttp.open('GET','http://192.192.152.89:8080/page/'+num,true);
  xhttp.send();
}
