function myShow() {
    alert("AAAA");
}
