function showTable(x){
	document.getElementById(x).style.zIndex=2;
	show_input();
}

function hideTable(x){
	document.getElementById(x).style.zIndex=0;
}

function onload(){
	var level = document.getElementById("userlevel").innerHTML;
	var count = 0;
	switch (level){
		case  "1":
			count = 4;
			break;
		case  "2":
			count = 8;
			break;
		case  "3":
			count = 12;
			break;
		default:
			count = 0;
			break;
	}
  for (var i=1; i <= count; i++){
    ajax_Tables(i);
	document.getElementById("fbt"+i).style.display='';
  }
    var query = location.search.substring(1);
   if(query.split("=")[0]=="token"){
      document.getElementById("token").innerHTML = query.split("=")[1];
   }
}

function ajax_Tables(i) {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById('div'+i).innerHTML = this.responseText;
      }
    };
    xhttp.open('POST', 'http://140.126.75.69:8088/table/'+i, true);
    xhttp.send();
}


function show_input(){
	var lis = document.getElementsByClassName('input');//数组
	var lisLen = lis.length;
	for(var i = 0;i < lisLen;i++){
		var num = lis[i].innerHTML;
//		$('td').each(function() {
//			tdWidth = $(this).width();
//		});
//		w = tdWidth/10;
		lis[i].innerHTML="<input type='text' name=num size='10' />";
	}
}

function ey(y) {
   document.getElementById(y).style.zIndex=2;
   var x = document.getElementById("top").querySelectorAll("font");
   x[0].innerHTML="<input id='ey1' onchange='check(this.id)'/>";

   var x = document.getElementById("data").querySelectorAll("font");
   for(i = 0; i < x.length; i++){
      switch(i+2){
	 case 3:
	    x[i].innerHTML="<select id='ey"+(i+2)+"' name='ey"+(i+2)+"' ><option value='M'>男</option><option value='F'>女</option></select>";
	    break;
	 case 4:
	    x[i].innerHTML="<select id='ey"+(i+2)+"' name='ey"+(i+2)+"' ><option value='A'>A</option><option value='B'>B</option><option value='O'>O</option><option value='AB'>AB</option></select>";
	    break;
         case 2: case 6: case 7: case 8: case 9: case 37: case 38: case 39: case 41: case 42: case 43:
            x[i].innerHTML="<input id='ey"+(i+2)+"' onchange='check(this.id)' size=8/>";
            break;
         case 10: case 11:
            x[i].innerHTML="<input id='ey"+(i+2)+"' onchange='check(this.id)' size=100 />";
            break;
         case 12: case 17: case 22: case 27: case 32:
            x[i].innerHTML="<input id='ey"+(i+2)+"' onchange='check(this.id)' size=20 />";
            break;
         case 16: case 21: case 26: case 31: case 36:
            x[i].innerHTML="<input id='ey"+(i+2)+"' onchange='check(this.id)' size=50 />";
            break;
         case 5: case 13: case 14: case 18: case 19: case 23: case 24: case 28: case 29: case 33: case 34: case 40:
            x[i].innerHTML="<input type='date' id='ey"+(i+2)+"' onchange='check(this.id)' style='width:75px' />";
            break;
         default:
            x[i].innerHTML="<input id='ey"+(i+2)+"' onchange='check(this.id)' size=5 />";
      } //End of switch value='<"+(i+2)+">'
   } //End fo for
} //End of show()
